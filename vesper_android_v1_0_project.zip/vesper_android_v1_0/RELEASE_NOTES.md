# Vesper Android 1.0.0 — primera base móvil

- Interfaz nativa inicial.
- Configuración de API base y X-API-Key.
- Health check y análisis combinado.
- Manejo de respuestas JSON y errores HTTP.
- HTTPS requerido para hosts remotos.
- Proyecto entregado sin keystore ni APK firmada para que el propietario genere y firme su propio artefacto.
