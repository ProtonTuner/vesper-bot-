# Vesper Android — proyecto para compilar y firmar

Este ZIP contiene un proyecto Android Studio nativo (Java, sin dependencias de UI externas) que se conecta a Vesper API v1.1. No contiene una APK compilada ni una clave de firma: debes compilar y firmar en tu propio entorno.

## Funciones
- Configurar la URL base y la clave `X-API-Key` desde la app.
- Comprobar `GET /health`.
- Enviar preguntas a `POST /v1/analyze`.
- Mostrar la respuesta, el estado, latencia e ID de solicitud.
- Manejar errores de conexión, validación y autenticación.
- Rechazar URL remotas HTTP; usa HTTPS para el servidor público.

## Requisitos
- Android Studio reciente.
- JDK 17.
- Android SDK Platform 35 y Build Tools instalados.
- Conexión a internet para que Gradle descargue Android Gradle Plugin 8.7.3.

## Abrir y compilar
1. Descomprime el ZIP.
2. En Android Studio, selecciona **Open** y abre la carpeta `VesperAndroid`.
3. Espera a que termine Gradle Sync e instala las plataformas SDK que Android Studio solicite.
4. Prueba primero en un emulador o dispositivo.
5. En la app, configura la URL HTTPS de tu Vesper API y la clave API que definiste en el servidor.
6. Pulsa **Probar conexión** y luego envía una pregunta de prueba.
7. Para crear la APK, usa **Build > Generate Signed Bundle / APK > APK**. Crea/selecciona tu keystore privado, elige la variante `release` y guarda la copia segura del keystore y sus contraseñas.

También puedes compilar una APK de depuración desde Android Studio para pruebas. El entorno donde se preparó este proyecto no tiene Android SDK/Gradle instalado, por lo que no se pudo generar ni ejecutar una APK aquí.

## Seguridad importante
- No compartas tu keystore ni la contraseña de firma.
- La clave API se introduce en el dispositivo y se guarda en preferencias privadas de la app; no está incrustada en el código fuente. Aun así, una clave compartida dentro de una app cliente puede extraerse de un dispositivo comprometido. Para una app pública, no distribuyas una clave maestra del servidor: conviene añadir cuentas de usuario y claves individuales de corta duración en la API.
- Usa HTTPS con certificado válido. La app no permite HTTP remoto.
- La app no contiene servicios de terceros ni manda las preguntas a otro proveedor; se comunica con la URL de API que configures.

## Ajustes de proyecto
- Application ID: `com.vesper.app`
- Nombre visible: `Vesper`
- Version: `1.0.0` (versionCode 1)
- minSdk 26 / targetSdk 35

## Compilar desde un teléfono Android (sin Android Studio)

El proyecto incluye `.github/workflows/build-apk.yml`. Puedes subir los archivos del proyecto a un repositorio GitHub y usar GitHub Actions para compilar una APK de prueba en la nube.

1. Crea un repositorio en GitHub desde el navegador del teléfono. Para mayor privacidad, elige **Private**.
2. Extrae el ZIP en el teléfono con la aplicación de archivos. Sube el **contenido** de la carpeta `vesper_android_v1_0` al repositorio, incluyendo la carpeta oculta `.github/workflows`.
3. Abre la pestaña **Actions** del repositorio y selecciona **Build Vesper APK**.
4. Pulsa **Run workflow** y espera a que termine el trabajo en verde.
5. Abre la ejecución terminada, baja a **Artifacts** y descarga `vesper-android-debug-apk`. Descomprime ese artefacto para obtener la APK.
6. Instala la APK de prueba si Android lo permite. Solo instala APKs que hayas generado tú y cuyo origen controles.

Esta compilación es una APK **debug** para probar, firmada automáticamente con una clave de depuración temporal. No es la versión de lanzamiento que firmarás con tu propia clave. No subas nunca un keystore, contraseñas ni claves de API al repositorio.

Si no aparece la pestaña Actions, revisa que el repositorio tenga habilitado GitHub Actions y que el archivo `.github/workflows/build-apk.yml` esté en la raíz del repositorio bajo la carpeta `.github/workflows/`.
