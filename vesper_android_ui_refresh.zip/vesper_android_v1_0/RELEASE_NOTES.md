# Vesper Android 1.1 — UI refresh

- Reworked the main screen with a clearer brand header and system-status panel.
- Made the question composer and Analyze action the primary focus.
- Redesigned the answer panel and metadata hierarchy.
- Moved API configuration into a secondary, clearly grouped section.
- Preserved existing API requests, validation, and local settings storage.
