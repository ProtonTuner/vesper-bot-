package com.vesper.app;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.View;
import android.view.ViewGroup;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final String PREFS = "vesper_settings";
    private static final String DEFAULT_BASE = "";
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private EditText baseUrlInput, apiKeyInput, promptInput;
    private TextView statusText, answerText, detailText;
    private Button analyzeButton, healthButton, saveButton;
    private LinearLayout root;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        getWindow().setStatusBarColor(Color.rgb(16, 17, 22));
        getWindow().setNavigationBarColor(Color.rgb(16, 17, 22));
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setVerticalScrollBarEnabled(false);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(18), dp(20), dp(30));
        root.setBackgroundColor(0xFF101116);
        scroll.addView(root);
        setContentView(scroll);

        // Brand header
        LinearLayout brandRow = new LinearLayout(this);
        brandRow.setGravity(Gravity.CENTER_VERTICAL);
        brandRow.setOrientation(LinearLayout.HORIZONTAL);
        TextView mark = text("V", 22, 0xFF17131F, true);
        mark.setGravity(Gravity.CENTER);
        mark.setBackground(round(0xFFB9A8FF, 16));
        LinearLayout.LayoutParams markParams = new LinearLayout.LayoutParams(dp(46), dp(46));
        brandRow.addView(mark, markParams);

        LinearLayout brandText = new LinearLayout(this);
        brandText.setOrientation(LinearLayout.VERTICAL);
        brandText.setPadding(dp(12), 0, 0, 0);
        TextView title = text("Vesper", 25, Color.WHITE, true);
        TextView version = text("ASISTENTE PERSONAL  ·  API 1.1", 10, 0xFF9A9CAB, true);
        brandText.addView(title);
        LinearLayout.LayoutParams versionParams = lpMatchTop(2);
        brandText.addView(version, versionParams);
        brandRow.addView(brandText, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        root.addView(brandRow, lpMatch());

        TextView intro = text("Ideas complejas, respuestas claras.", 15, 0xFFB8BBC7, false);
        intro.setPadding(0, dp(16), 0, dp(18));
        root.addView(intro);

        // Connection status strip
        LinearLayout statusCard = new LinearLayout(this);
        statusCard.setOrientation(LinearLayout.VERTICAL);
        statusCard.setPadding(dp(15), dp(13), dp(15), dp(13));
        statusCard.setBackground(round(0xFF1A1B23, 16));
        TextView connectionLabel = text("ESTADO DEL SISTEMA", 10, 0xFF9A9CAB, true);
        statusCard.addView(connectionLabel);
        statusText = text("Sin conexión comprobada. Configura tu API para comenzar.", 13, 0xFFD7D8E0, false);
        statusText.setPadding(0, dp(5), 0, 0);
        statusCard.addView(statusText);
        root.addView(statusCard, lpMatch());

        // Prompt card
        LinearLayout promptCard = card();
        TextView promptTitle = text("¿En qué te ayudo?", 21, Color.WHITE, true);
        promptCard.addView(promptTitle);
        TextView promptHint = text("Describe tu pregunta o problema y lo analizaremos paso a paso.", 13, 0xFF9FA2B1, false);
        promptHint.setPadding(0, dp(5), 0, dp(14));
        promptCard.addView(promptHint);
        promptInput = edit("Escribe aquí tu pregunta…", false);
        promptInput.setSingleLine(false);
        promptInput.setMinLines(4);
        promptInput.setMaxLines(8);
        promptInput.setGravity(Gravity.TOP | Gravity.START);
        promptInput.setPadding(dp(15), dp(14), dp(15), dp(14));
        promptInput.setBackground(round(0xFF171820, 13));
        promptCard.addView(promptInput, lpMatch());
        analyzeButton = button("Analizar pregunta   →", false);
        LinearLayout.LayoutParams analyzeParams = lpMatchTop(12);
        analyzeParams.height = dp(52);
        promptCard.addView(analyzeButton, analyzeParams);
        analyzeButton.setOnClickListener(v -> analyze());
        LinearLayout.LayoutParams promptCardParams = lpMatchTop(16);
        root.addView(promptCard, promptCardParams);

        // Answer panel
        LinearLayout answerCard = card();
        LinearLayout answerHeader = new LinearLayout(this);
        answerHeader.setOrientation(LinearLayout.HORIZONTAL);
        answerHeader.setGravity(Gravity.CENTER_VERTICAL);
        TextView answerTitle = text("Respuesta", 19, Color.WHITE, true);
        answerHeader.addView(answerTitle, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1));
        TextView answerBadge = text("RESULTADO", 9, 0xFFB9A8FF, true);
        answerBadge.setPadding(dp(9), dp(6), dp(9), dp(6));
        answerBadge.setBackground(round(0xFF302C3D, 10));
        answerHeader.addView(answerBadge);
        answerCard.addView(answerHeader);
        answerText = text("Tu respuesta aparecerá aquí. Cuando estés listo, escribe una pregunta y pulsa Analizar.", 15, 0xFFD9DAE2, false);
        answerText.setLineSpacing(dp(3), 1.0f);
        answerText.setPadding(0, dp(15), 0, dp(8));
        answerCard.addView(answerText, lpMatch());
        detailText = text("", 11, 0xFF9295A4, false);
        detailText.setPadding(0, dp(8), 0, 0);
        answerCard.addView(detailText, lpMatch());
        LinearLayout.LayoutParams answerParams = lpMatchTop(14);
        root.addView(answerCard, answerParams);

        // Settings section, visually secondary to the main workflow
        TextView settingsTitle = text("CONFIGURACIÓN", 11, 0xFF9A9CAB, true);
        settingsTitle.setPadding(dp(2), dp(24), 0, dp(9));
        root.addView(settingsTitle);
        LinearLayout settingsCard = card();
        TextView settingsHeading = text("Conexión con tu API", 16, Color.WHITE, true);
        settingsCard.addView(settingsHeading);
        TextView settingsDescription = text("Estos datos se guardan solo en este dispositivo.", 12, 0xFF9FA2B1, false);
        settingsDescription.setPadding(0, dp(4), 0, dp(12));
        settingsCard.addView(settingsDescription);
        baseUrlInput = edit("URL base · https://tu-servidor", false);
        baseUrlInput.setText(prefs.getString("base_url", DEFAULT_BASE));
        settingsCard.addView(baseUrlInput, lpMatch());
        apiKeyInput = edit("Clave API (X-API-Key)", true);
        apiKeyInput.setText(prefs.getString("api_key", ""));
        settingsCard.addView(apiKeyInput, lpMatchTop(9));

        LinearLayout settingsActions = new LinearLayout(this);
        settingsActions.setOrientation(LinearLayout.HORIZONTAL);
        saveButton = button("Guardar", true);
        healthButton = button("Probar conexión", false);
        LinearLayout.LayoutParams saveParams = new LinearLayout.LayoutParams(0, dp(48), 1);
        saveParams.rightMargin = dp(8);
        settingsActions.addView(saveButton, saveParams);
        settingsActions.addView(healthButton, new LinearLayout.LayoutParams(0, dp(48), 1));
        settingsCard.addView(settingsActions, lpMatchTop(10));
        saveButton.setOnClickListener(v -> saveSettings());
        healthButton.setOnClickListener(v -> checkHealth());
        root.addView(settingsCard, lpMatch());

        TextView foot = text("Usa HTTPS para conexiones remotas. No incluyas tu clave API en capturas ni la compartas.", 11, 0xFF777B8A, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(dp(8), dp(18), dp(8), 0);
        root.addView(foot, lpMatch());
    }

    private LinearLayout card() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(17), dp(16), dp(17));
        box.setBackground(round(0xFF20212A, 18));
        return box;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private EditText edit(String hint, boolean secret) {
        EditText e = new EditText(this);
        e.setSingleLine(!hint.startsWith("URL"));
        e.setHint(hint);
        e.setTextSize(14);
        e.setTextColor(Color.WHITE);
        e.setMinHeight(dp(48));
        e.setHintTextColor(0xFF858997);
        e.setBackground(panel());
        e.setPadding(dp(14), dp(12), dp(14), dp(12));
        if (secret) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        else if (hint.startsWith("URL")) e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        return e;
    }

    private Button button(String label, boolean secondary) {
        Button b = new Button(this);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextSize(14);
        b.setMinHeight(dp(48));
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setTextColor(secondary ? Color.WHITE : 0xFF17131F);
        b.setBackground(round(secondary ? 0xFF302C3D : 0xFFB9A8FF, 14));
        return b;
    }

    private GradientDrawable panel() { return round(0xFF20212A, 14); }
    private GradientDrawable round(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), 0xFF353743); return d;
    }
    private LinearLayout.LayoutParams lpMatch() { return new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT); }
    private LinearLayout.LayoutParams lpMatchTop(int top) { LinearLayout.LayoutParams p = lpMatch(); p.topMargin = dp(top); return p; }
    private int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }

    private void saveSettings() {
        String base = baseUrlInput.getText().toString().trim();
        String key = apiKeyInput.getText().toString().trim();
        if (base.endsWith("/")) base = base.substring(0, base.length() - 1);
        if (base.isEmpty() || !(base.startsWith("https://") || base.startsWith("http://10.0.2.2") || base.startsWith("http://localhost"))) {
            statusText.setText("Introduce una URL HTTPS válida. HTTP solo se acepta para el emulador local."); return;
        }
        if (base.startsWith("http://") && !(base.startsWith("http://10.0.2.2") || base.startsWith("http://localhost"))) {
            statusText.setText("Por seguridad, la API remota debe usar HTTPS."); return;
        }
        prefs.edit().putString("base_url", base).putString("api_key", key).apply();
        statusText.setText("Configuración guardada en este dispositivo.");
    }

    private String baseUrl() { return prefs.getString("base_url", "").trim().replaceAll("/+$", ""); }
    private String apiKey() { return prefs.getString("api_key", "").trim(); }

    private void checkHealth() {
        saveSettings();
        String base = baseUrl();
        if (base.isEmpty()) return;
        setBusy(true, "Comprobando conexión…");
        request("GET", base + "/health", null, false, result -> {
            setBusy(false, null);
            if (result.code >= 200 && result.code < 300) {
                try {
                    JSONObject j = new JSONObject(result.body);
                    statusText.setText("Conectada · " + j.optString("service", "vesper-api") + " · versión " + j.optString("version", "?"));
                } catch (Exception e) { statusText.setText("El servidor respondió, pero el JSON no tiene el formato esperado."); }
            } else statusText.setText("No se pudo conectar (HTTP " + result.code + "): " + safeMessage(result.body));
        });
    }

    private void analyze() {
        saveSettings();
        String base = baseUrl();
        String key = apiKey();
        String prompt = promptInput.getText().toString().trim();
        if (base.isEmpty()) return;
        if (key.length() < 24) { statusText.setText("La clave parece demasiado corta. Revisa VESPER_API_KEY en el servidor."); return; }
        if (prompt.isEmpty()) { statusText.setText("Escribe una pregunta primero."); return; }
        if (prompt.length() > 1200) { statusText.setText("La pregunta supera el límite de 1200 caracteres."); return; }
        setBusy(true, "Vesper está analizando…");
        JSONObject body = new JSONObject();
        try { body.put("text", prompt); } catch (Exception ignored) {}
        request("POST", base + "/v1/analyze", body.toString(), true, result -> {
            setBusy(false, null);
            try {
                JSONObject j = new JSONObject(result.body);
                if (result.code >= 200 && result.code < 300) {
                    String answer = j.isNull("answer") ? "Vesper no encontró una respuesta concluyente." : j.optString("answer", "Vesper no encontró una respuesta concluyente.");
                    answerText.setText(answer);
                    detailText.setText("Estado: " + j.optString("status", "desconocido") + " · " + j.optDouble("elapsed_ms", 0) + " ms · ID: " + j.optString("request_id", "n/a"));
                    statusText.setText("Análisis completado.");
                } else {
                    JSONObject err = j.optJSONObject("error");
                    String msg = err != null ? err.optString("message", "Error de API") : j.optString("detail", "Error de API");
                    statusText.setText("Error HTTP " + result.code + ": " + msg);
                    detailText.setText("ID de solicitud: " + (err == null ? "no disponible" : err.optString("request_id", "no disponible")));
                }
            } catch (Exception e) {
                statusText.setText("Respuesta inesperada del servidor (HTTP " + result.code + ").");
                detailText.setText("Comprueba que la URL apunta a Vesper API v1.1.");
            }
        });
    }

    private interface Callback { void done(NetResult result); }
    private static class NetResult { int code; String body; NetResult(int c, String b) { code=c; body=b; } }

    private void request(String method, String urlText, String body, boolean auth, Callback callback) {
        executor.execute(() -> {
            HttpURLConnection conn = null; NetResult result;
            try {
                URL url = new URL(urlText);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod(method); conn.setConnectTimeout(12000); conn.setReadTimeout(20000);
                conn.setRequestProperty("Accept", "application/json");
                if (auth) conn.setRequestProperty("X-API-Key", apiKey());
                if (body != null) {
                    conn.setDoOutput(true); conn.setRequestProperty("Content-Type", "application/json; charset=utf-8");
                    try (OutputStream os = conn.getOutputStream()) { os.write(body.getBytes(StandardCharsets.UTF_8)); }
                }
                int code = conn.getResponseCode();
                InputStream stream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
                StringBuilder out = new StringBuilder();
                if (stream != null) try (BufferedReader reader = new BufferedReader(new InputStreamReader(stream, StandardCharsets.UTF_8))) {
                    String line; while ((line = reader.readLine()) != null) out.append(line);
                }
                result = new NetResult(code, out.toString());
            } catch (Exception e) { result = new NetResult(-1, e.getClass().getSimpleName() + ": " + (e.getMessage() == null ? "sin detalles" : e.getMessage())); }
            finally { if (conn != null) conn.disconnect(); }
            NetResult finalResult = result;
            main.post(() -> callback.done(finalResult));
        });
    }

    private String safeMessage(String raw) {
        if (raw == null || raw.isEmpty()) return "sin detalles";
        return raw.length() > 180 ? raw.substring(0, 180) + "…" : raw;
    }
    private void setBusy(boolean busy, String message) {
        analyzeButton.setEnabled(!busy); healthButton.setEnabled(!busy); saveButton.setEnabled(!busy);
        analyzeButton.setAlpha(busy ? 0.5f : 1f); healthButton.setAlpha(busy ? 0.5f : 1f); saveButton.setAlpha(busy ? 0.5f : 1f);
        if (message != null) statusText.setText(message);
    }
    @Override protected void onDestroy() { executor.shutdownNow(); super.onDestroy(); }
}
