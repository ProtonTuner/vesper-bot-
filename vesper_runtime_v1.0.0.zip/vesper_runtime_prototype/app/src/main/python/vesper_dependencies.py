"""Strict, conservative requirements.txt validator for Vesper Runtime.

This checks manifest syntax and guards the app's export/build workflow. It does
not prove a package has an Android-compatible wheel; only the actual Chaquopy
Gradle build can confirm that.
"""
from __future__ import annotations

import json
import re

MAX_REQUIREMENTS_CHARS = 32_768
MAX_REQUIREMENT_LINES = 200
_NAME_RE = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9._-]*[A-Za-z0-9])?$")
_EXTRA_RE = re.compile(r"^[A-Za-z0-9](?:[A-Za-z0-9._-]*[A-Za-z0-9])?$")
_PACKAGE_RE = re.compile(
    r"^([A-Za-z0-9][A-Za-z0-9._-]*)(?:\[([A-Za-z0-9][A-Za-z0-9._,-]*)\])?(.*)$"
)
_SPEC_RE = re.compile(r"^(===|==|~=|!=|<=|>=|<|>)[ \t]*([A-Za-z0-9][A-Za-z0-9.!+*_-]*)$")


def _normalize_name(name: str) -> str:
    return re.sub(r"[-_.]+", "-", name).lower()


def parse_requirements(contents: str) -> dict:
    """Return validation details for a restricted, portable requirements file."""
    errors = []
    requirements = []
    seen = {}

    if not isinstance(contents, str):
        return {
            "valid": False, "requirements": [], "errors": ["Requirements content must be text."],
            "warnings": [], "normalized_text": ""
        }
    if len(contents) > MAX_REQUIREMENTS_CHARS:
        return {
            "valid": False, "requirements": [],
            "errors": [f"File exceeds {MAX_REQUIREMENTS_CHARS} characters."],
            "warnings": [], "normalized_text": ""
        }

    physical_lines = contents.splitlines()
    if len(physical_lines) > MAX_REQUIREMENT_LINES * 4:
        return {
            "valid": False, "requirements": [],
            "errors": [f"File has too many lines; maximum is {MAX_REQUIREMENT_LINES * 4} including comments."],
            "warnings": [], "normalized_text": ""
        }

    for line_number, raw_line in enumerate(physical_lines, start=1):
        # Inline comments are only allowed when separated by whitespace.
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if " #" in line or "\t#" in line:
            line = re.split(r"[ \t]+#", line, maxsplit=1)[0].strip()
        if not line:
            continue
        if line.startswith("-"):
            errors.append(f"Line {line_number}: pip options/directives are not allowed; list packages only.")
            continue
        if any(token in line for token in ("://", "git+", "file:", " @ ")) or line.startswith((".", "/", "\\")):
            errors.append(f"Line {line_number}: URLs, VCS references and local paths are not supported.")
            continue
        if ";" in line:
            errors.append(f"Line {line_number}: environment markers are not supported by this validator.")
            continue

        match = _PACKAGE_RE.fullmatch(line)
        if not match:
            errors.append(f"Line {line_number}: invalid requirement syntax: {line[:100]}")
            continue
        package_name, extras_text, rest = match.groups()
        if not _NAME_RE.fullmatch(package_name):
            errors.append(f"Line {line_number}: invalid package name.")
            continue
        if extras_text:
            extras = extras_text.split(",")
            if any(not _EXTRA_RE.fullmatch(extra) for extra in extras):
                errors.append(f"Line {line_number}: invalid extras list.")
                continue
            if len({_normalize_name(extra) for extra in extras}) != len(extras):
                errors.append(f"Line {line_number}: duplicate extras are not allowed.")
                continue

        rest = rest.strip()
        specifiers = []
        if rest:
            for chunk in rest.split(","):
                chunk = chunk.strip()
                spec_match = _SPEC_RE.fullmatch(chunk)
                if not spec_match:
                    errors.append(
                        f"Line {line_number}: invalid version constraint '{chunk}'. Use forms such as ==1.2, >=1.2,<2.0."
                    )
                    specifiers = []
                    break
                operator, version = spec_match.groups()
                if "*" in version and not (operator in ("==", "!=") and version.endswith(".*") and "*" not in version[:-1]):
                    errors.append(f"Line {line_number}: wildcard versions are only supported as ==1.2.* or !=1.2.*.")
                    specifiers = []
                    break
                specifiers.append(operator + version)
            if not specifiers:
                continue

        normalized_key = _normalize_name(package_name)
        if normalized_key in seen:
            errors.append(
                f"Line {line_number}: duplicate package '{package_name}' (first listed on line {seen[normalized_key]})."
            )
            continue
        seen[normalized_key] = line_number

        canonical = package_name
        if extras_text:
            canonical += "[" + ",".join(extras_text.split(",")) + "]"
        canonical += ",".join(specifiers)
        requirements.append(canonical)

    if len(requirements) > MAX_REQUIREMENT_LINES:
        errors.append(f"At most {MAX_REQUIREMENT_LINES} package requirements are allowed.")

    warnings = [
        "Syntax validation does not verify Android wheel availability or native-library compatibility.",
        "Packages are bundled by Chaquopy during an APK build; saving this list does not install packages into the current APK."
    ]
    normalized_text = contents.strip()
    if normalized_text:
        normalized_text += "\n"
    else:
        normalized_text = "# Vesper Runtime Python dependencies\n"
    return {
        "valid": not errors,
        "requirements": requirements,
        "errors": errors,
        "warnings": warnings,
        "normalized_text": normalized_text,
    }


def validate_requirements_json(contents: str) -> str:
    """JSON wrapper for a simple Kotlin/Chaquopy bridge."""
    return json.dumps(parse_requirements(contents), ensure_ascii=False)
