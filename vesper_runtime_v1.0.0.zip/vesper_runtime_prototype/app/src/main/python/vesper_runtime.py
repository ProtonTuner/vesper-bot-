"""Embedded Python runner used by Vesper Runtime.

This module is an execution helper, not a security sandbox. Python code entered by
an app user has the same process permissions as the Android application.
"""
from __future__ import annotations

import contextlib
import os
import sys
import traceback
import threading
from pathlib import Path
from typing import Optional, TextIO

DEFAULT_OUTPUT_LIMIT = 100_000
TRUNCATION_MARKER = "\n...[output truncated: limit reached]...\n"
_RUN_LOCK = threading.RLock()
_STOP_EVENT = threading.Event()


class RuntimeStopped(Exception):
    """Raised when the user requests cooperative cancellation."""


def request_stop() -> bool:
    """Request that the currently running Python script stop at its next trace event.

    This cannot interrupt a native extension or a blocking system call until it
    returns to Python. Scripts can also deliberately disable tracing, so this is
    a best-effort user stop, not a security boundary.
    """
    _STOP_EVENT.set()
    return True


def _cancel_trace(frame, event, arg):
    if _STOP_EVENT.is_set():
        raise RuntimeStopped("Execution stopped by user")
    return _cancel_trace


class BoundedTextWriter:
    """Text stream that caps captured output to avoid unbounded StringIO growth."""

    def __init__(self, max_chars: int = DEFAULT_OUTPUT_LIMIT, mirror: Optional[TextIO] = None) -> None:
        if max_chars < 1:
            raise ValueError("max_chars must be positive")
        self.max_chars = max_chars
        self._parts: list[str] = []
        self._length = 0
        self._truncated = False
        self._mirror = mirror
        self._mirror_marker_written = False

    def _mirror_write(self, value: str) -> None:
        if self._mirror is None or not value:
            return
        try:
            self._mirror.write(value)
            self._mirror.flush()
        except (OSError, ValueError):
            # Preserve in-memory execution/output if the device runs out of space
            # or the optional live-log stream becomes unavailable.
            self._mirror = None

    def write(self, value: str) -> int:
        if not isinstance(value, str):
            raise TypeError("write() argument must be str")
        original_length = len(value)
        if self._truncated or not value:
            return original_length

        remaining = self.max_chars - self._length
        if len(value) <= remaining:
            self._parts.append(value)
            self._length += len(value)
            self._mirror_write(value)
        else:
            accepted = value[:max(0, remaining)]
            if accepted:
                self._parts.append(accepted)
                self._length += len(accepted)
                self._mirror_write(accepted)
            self._truncated = True
            if not self._mirror_marker_written:
                self._mirror_write(TRUNCATION_MARKER)
                self._mirror_marker_written = True
        return original_length

    def flush(self) -> None:
        return None

    def getvalue(self) -> str:
        result = "".join(self._parts)
        if self._truncated:
            marker = TRUNCATION_MARKER
            # Keep the total returned result close to the requested output cap.
            result = result[: max(0, self.max_chars - len(marker))] + marker[: self.max_chars]
        return result


def _run_code_unlocked(
    code: str,
    project_dir: str,
    script_name: str = "main.py",
    log_file_path: Optional[str] = None,
    max_output_chars: int = DEFAULT_OUTPUT_LIMIT,
) -> str:
    """Execute Python code and return captured stdout/stderr.

    Args:
        code: Source text to execute.
        project_dir: Existing project directory; used as the process working directory.
        script_name: Python filename shown in tracebacks and as ``__file__``.
        log_file_path: Optional bounded sidecar output log, flushed for live display.
        max_output_chars: Maximum number of characters captured per stream.

    Note: This function changes the interpreter process's working directory and
    redirects stdout/stderr while the script runs. The Android app therefore must
    serialize calls to this function. It is not safe for untrusted scripts.
    """
    if not isinstance(code, str):
        raise TypeError("code must be a string")
    if (not isinstance(script_name, str) or not script_name or
            Path(script_name).name != script_name or "/" in script_name or "\\" in script_name or "\x00" in script_name):
        raise ValueError("script_name must be a simple filename")
    if not script_name.lower().endswith(".py"):
        raise ValueError("script_name must end in .py")

    project_path = Path(project_dir).resolve()
    if not project_path.is_dir():
        raise NotADirectoryError(f"Project directory does not exist: {project_path}")

    log_stream = None
    if log_file_path is not None:
        try:
            log_stream = open(log_file_path, "w", encoding="utf-8")
        except OSError:
            # Execution remains available even if live logging cannot be opened.
            log_stream = None
    stdout = BoundedTextWriter(max_output_chars, log_stream)
    stderr = BoundedTextWriter(max_output_chars, log_stream)
    previous_cwd = os.getcwd()
    script_path = str(project_path / script_name)
    namespace = {"__name__": "__main__", "__file__": script_path}
    previous_trace = sys.gettrace()
    try:
        os.chdir(project_path)
        # A fresh run clears any stop request from the preceding script.
        _STOP_EVENT.clear()
        with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
            sys.settrace(_cancel_trace)
            try:
                exec(compile(code, script_path, "exec"), namespace, namespace)
            except RuntimeStopped:
                # Clear before writing the message, otherwise the trace hook would
                # immediately raise again while this cleanup code runs.
                _STOP_EVENT.clear()
                stdout.write("\n[Execution stopped by user]\n")
            except BaseException:
                # Capture syntax/runtime errors, including SystemExit, instead of
                # letting user code accidentally terminate the runner thread.
                try:
                    stderr.write(traceback.format_exc())
                except Exception:
                    pass
            finally:
                sys.settrace(previous_trace)
    finally:
        sys.settrace(previous_trace)
        _STOP_EVENT.clear()
        os.chdir(previous_cwd)
        if log_stream is not None:
            try:
                log_stream.close()
            except OSError:
                pass

    out_text = stdout.getvalue().rstrip("\n")
    err_text = stderr.getvalue().rstrip("\n")
    chunks = [chunk for chunk in (out_text, err_text) if chunk]
    return "\n".join(chunks) if chunks else "Script completed with no output."


def run_code(
    code: str,
    project_dir: str,
    script_name: str = "main.py",
    log_file_path: Optional[str] = None,
    max_output_chars: int = DEFAULT_OUTPUT_LIMIT,
) -> str:
    """Serialize script execution because cwd and stdout/stderr are process-global."""
    with _RUN_LOCK:
        return _run_code_unlocked(code, project_dir, script_name, log_file_path, max_output_chars)
