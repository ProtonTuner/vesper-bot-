print("Vesper Runtime is ready.")
print("Python is running inside the Android app.")
for n in range(1, 4):
    print(f"Embedded runtime test: {n}")
