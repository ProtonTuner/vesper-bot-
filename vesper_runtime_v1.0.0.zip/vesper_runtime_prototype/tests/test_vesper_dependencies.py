import importlib.util
import json
import unittest
from pathlib import Path

MODULE_PATH = Path(__file__).parents[1] / "app" / "src" / "main" / "python" / "vesper_dependencies.py"
spec = importlib.util.spec_from_file_location("vesper_dependencies", MODULE_PATH)
vesper_dependencies = importlib.util.module_from_spec(spec)
assert spec.loader is not None
spec.loader.exec_module(vesper_dependencies)


class RequirementsTests(unittest.TestCase):
    def test_accepts_blank_and_comments(self):
        result = vesper_dependencies.parse_requirements("# comment\n\n   \n")
        self.assertTrue(result["valid"])
        self.assertEqual(result["requirements"], [])

    def test_accepts_unpinned_package(self):
        result = vesper_dependencies.parse_requirements("requests")
        self.assertTrue(result["valid"])
        self.assertEqual(result["requirements"], ["requests"])

    def test_accepts_version_ranges_and_extras(self):
        result = vesper_dependencies.parse_requirements("HTTPX[http2]>=0.26,<1.0\nfoo-bar==1.2.3")
        self.assertTrue(result["valid"], result["errors"])
        self.assertEqual(result["requirements"], ["HTTPX[http2]>=0.26,<1.0", "foo-bar==1.2.3"])

    def test_ignores_inline_comment_separated_by_space(self):
        result = vesper_dependencies.parse_requirements("requests>=2.0 # pinned later")
        self.assertTrue(result["valid"])
        self.assertEqual(result["requirements"], ["requests>=2.0"])

    def test_rejects_duplicate_normalized_names(self):
        result = vesper_dependencies.parse_requirements("my_pkg==1.0\nmy-pkg==2.0")
        self.assertFalse(result["valid"])
        self.assertTrue(any("duplicate package" in error for error in result["errors"]))

    def test_rejects_pip_options(self):
        result = vesper_dependencies.parse_requirements("--extra-index-url https://example.invalid/simple")
        self.assertFalse(result["valid"])
        self.assertTrue(result["errors"])

    def test_rejects_direct_urls_and_vcs(self):
        for line in ("pkg @ https://example.invalid/pkg.whl", "git+https://example.invalid/a.git", "file:///tmp/pkg.whl"):
            with self.subTest(line=line):
                self.assertFalse(vesper_dependencies.parse_requirements(line)["valid"])

    def test_rejects_local_paths(self):
        for line in ("./local-package", "/tmp/pkg.whl", r"C:\\temp\\pkg.whl"):
            with self.subTest(line=line):
                self.assertFalse(vesper_dependencies.parse_requirements(line)["valid"])

    def test_rejects_package_names_with_invalid_trailing_punctuation(self):
        for line in ("requests.", "-badpkg", "badpkg_"):
            with self.subTest(line=line):
                self.assertFalse(vesper_dependencies.parse_requirements(line)["valid"])

    def test_rejects_environment_markers(self):
        result = vesper_dependencies.parse_requirements("colorama; sys_platform == 'win32'")
        self.assertFalse(result["valid"])
        self.assertTrue(any("environment markers" in error for error in result["errors"]))

    def test_accepts_pep440_wildcard_equality(self):
        result = vesper_dependencies.parse_requirements("package==1.2.*")
        self.assertTrue(result["valid"], result["errors"])
        self.assertEqual(result["requirements"], ["package==1.2.*"])

    def test_rejects_wildcard_with_ordered_comparison(self):
        result = vesper_dependencies.parse_requirements("package>=1.2.*")
        self.assertFalse(result["valid"])

    def test_rejects_invalid_versions(self):
        for line in ("requests=>2.0", "requests==", "requests>=bad version"):
            with self.subTest(line=line):
                self.assertFalse(vesper_dependencies.parse_requirements(line)["valid"])

    def test_rejects_too_large_file(self):
        result = vesper_dependencies.parse_requirements("#" + "x" * (vesper_dependencies.MAX_REQUIREMENTS_CHARS + 2))
        self.assertFalse(result["valid"])
        self.assertTrue(any("exceeds" in error for error in result["errors"]))

    def test_json_bridge_is_parseable(self):
        decoded = json.loads(vesper_dependencies.validate_requirements_json("requests==2.32.0"))
        self.assertTrue(decoded["valid"])
        self.assertEqual(decoded["requirements"], ["requests==2.32.0"])
        self.assertIn("normalized_text", decoded)

    def test_rejects_non_text(self):
        result = vesper_dependencies.parse_requirements(None)
        self.assertFalse(result["valid"])
        self.assertTrue(result["errors"])


if __name__ == "__main__":
    unittest.main()
